import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import os

current_dir = os.path.dirname(os.path.abspath(__file__))

GDP_PATH = os.path.join(current_dir, "data", "China_GDP.csv")
HOURS_PATH = os.path.join(current_dir, "data", "周工作时数（年的）.xlsx")
OUTPUT_PATH = os.path.join(current_dir, "output", "中国周工作时数完整数据_2000-2023.csv")
os.makedirs(os.path.dirname(GDP_PATH), exist_ok=True)

try:
    gdp = pd.read_csv(GDP_PATH, encoding='utf-8-sig')
except FileNotFoundError:
    print(f"错误：无法找到文件 {GDP_PATH}")
    print("请确保文件已解压到 data 文件夹中")
    raise

try:
    hours = pd.read_excel(HOURS_PATH, engine='openpyxl')
except FileNotFoundError:
    print(f"错误：无法找到文件 {HOURS_PATH}")
    print("请确保文件已解压到 data 文件夹中")
    raise

gdp = gdp.dropna(subset=['Year'])
gdp['Year'] = (
    gdp['Year']
    .astype(str)  # 确保转换为字符串
    .str.replace(r'[^0-9]', '', regex=True)
    .replace('', np.nan)
    .dropna()
    .astype(int))
gdp = gdp[['Year', 'china_GDP']].dropna()

hours.rename(columns={'Year': 'Year', '周工作时数': 'Hours'}, inplace=True)
hours['Year'] = hours['Year'].astype(int)

years = pd.DataFrame({'Year': range(2000, 2024)})

merged = (
    years
    .merge(gdp, on='Year', how='left')
    .merge(hours, on='Year', how='left'))

merged['GDP_growth'] = merged['china_GDP'].pct_change(fill_method=None) * 100  # 年增长率
merged['GDP_3yr_avg'] = merged['china_GDP'].rolling(3, min_periods=1).mean()   # 三年移动平均
merged[['china_GDP', 'GDP_growth', 'GDP_3yr_avg']] = merged[['china_GDP', 'GDP_growth', 'GDP_3yr_avg']].ffill()

train_data = merged[merged['Year'] >= 2018].dropna()

if len(train_data) >= 3:
    features = ['china_GDP', 'GDP_growth', 'GDP_3yr_avg']
    scaler = StandardScaler()
    X_train = scaler.fit_transform(train_data[features])
    y_train = train_data['Hours']
    
    model = RandomForestRegressor(n_estimators=200, max_depth=3, random_state=42)
    model.fit(X_train, y_train)
    
    predict_years = merged[merged['Year'] <= 2017]
    X_pred = scaler.transform(predict_years[features])
    predictions = model.predict(X_pred)
    
    merged.loc[predict_years.index, 'Hours'] = np.clip(predictions, 40, 50)

merged['Hours'] = (
    merged['Hours']
    .interpolate(method='linear')
    .ffill()
    .bfill()
    .round(1))

final_df = merged[['Year', 'Hours']].rename(columns={
    'Year': '年份',
    'Hours': '周工作时数'})

os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

try:
    final_df.to_csv(OUTPUT_PATH, index=False, encoding='gb18030')
    print(f"处理成功！文件已保存至：{os.path.abspath(OUTPUT_PATH)}")
except PermissionError:
    print("错误：文件保存失败，请关闭Excel等程序后重试")
except Exception as e:
    print(f"未知错误：{str(e)}")
