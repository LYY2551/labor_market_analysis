import pandas as pd
import os

current_dir = os.path.dirname(os.path.abspath(__file__))

EXCHANGE_PATH = os.path.join(current_dir, "data", "中美汇率.xlsx")
EARNINGS_PATH = os.path.join(current_dir, "data", "Median_Weekly_Earnings_Annual.csv")
OUTPUT_PATH = os.path.join(current_dir, "output", "Annual_U.S._Median_Weekly_Earnings_Annual.csv")

os.makedirs(os.path.dirname(EXCHANGE_PATH), exist_ok=True)

exchange_df = pd.read_excel(EXCHANGE_PATH, sheet_name='Sheet1', engine='openpyxl')
earnings_df = pd.read_csv(EARNINGS_PATH)
exchange_df = exchange_df.sort_values('Year', ascending=True)  # 将汇率数据按年份正序排列
earnings_df = earnings_df.sort_values('Year', ascending=True)  # 周薪数据已正序，此步可选

merged_df = pd.merge(earnings_df, exchange_df, on='Year', how='inner')

merged_df['Weekly_Earnings_RMB'] = (
    merged_df['Annual Median Weekly Earnings (Dollars)'] 
    * merged_df['Exchange_Rate'])

merged_df['Weekly_Earnings_RMB'] = merged_df['Weekly_Earnings_RMB'].round(2)
merged_df = merged_df.sort_values('Year')

os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

merged_df.to_csv(OUTPUT_PATH, index=False, encoding='gb18030')
print(f"处理成功！文件已保存至：{os.path.abspath(OUTPUT_PATH)}")
